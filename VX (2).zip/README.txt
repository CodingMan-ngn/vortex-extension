HELLO ITS UR ACTIVE DEVELOPER fle__x from discord i am writing this to inform whoever downloads
this that eveerythig on this exe is totally safe and there is no such virus anything, all it 
does is fetch the vortex zip folder from github and extract its content please note that nothing
here is meant to cause your device harm. I hope you keep supporting my little work with your 
reviews. FROM VORTEX TEAM 
**NOTE ** KEEP THE INSTALLER AND THE INSTALLED FOLDER IN A NEW FOLDER AND WHENEVER THE EXTENSIO
IS UPDATED ALL U NEED TO DO IS RUN THE INSTALLER IT AUTO DELETES THE OLD ONE AND INSTALLS THE 
UPDATED VERSION THANK YOU GUYS . PEACE OUT **





**NOTE NO VIRUS ** STOP LOSTENING TO RUNMORS FROM LITTLE TIMMYS **

THE PASSWORD IS "VORTEX" or vortex am not sure 